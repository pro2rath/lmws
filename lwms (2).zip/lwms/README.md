# Worker Identification and Complaint Management System

This project is a web-based system for verifying workers using Aadhaar/Ration card numbers and allowing users to file complaints against fraudulent or unregistered workers. The admin can view registered workers and complaints.

## Features
- Aadhaar/Ration card verification
- Worker registration with image upload
- Complaint submission form
- Admin dashboard to view workers and complaints
- Tamil + English support
- Privacy policy page

## Tech Stack
- Python 3.x
- Flask
- HTML, CSS, JavaScript (Bootstrap)
- SQLite for database

## Directory Structure
# LWMS - Labour Worker Management System

LWMS is a simple Flask-based web application for managing a directory of daily wage labourers. It allows workers to register, an admin to verify them, and employers to search for available workers.

## Features

- **Worker Registration**: Workers can register with their name, phone, work type, location, and ID proofs (Aadhaar, Ration Card, Selfie).
- **Admin Verification**: An admin must approve new registrations before they appear in public search results.
- **Search & Filter**: Employers can search for verified workers and filter by work type and location.
- **Daily Availability**: Workers can mark themselves as "available for today," making it easy for employers to find immediate help.
- **Complaint System**: Users can submit complaints against workers, which are reviewed by the admin.
- **Admin Panel**: A secure panel to manage workers (verify, block, delete) and review complaints.
- **Bilingual Support**: UI elements and templates support both English and Tamil.

## Project Structure
