-- lwms/schema.sql
DROP TABLE IF EXISTS workers;
DROP TABLE IF EXISTS complaints;

CREATE TABLE workers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    work_type TEXT NOT NULL,
    location TEXT NOT NULL, -- Added location field
    aadhaar_path TEXT,
    rationcard_path TEXT,
    selfie_path TEXT NOT NULL,
    verified_status INTEGER NOT NULL DEFAULT 0, -- 0: Unverified, 1: Verified, 2: Rejected
    is_blocked INTEGER NOT NULL DEFAULT 0, -- 0: Not blocked, 1: Blocked
    last_available_date DATE,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE complaints (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    worker_id INTEGER NOT NULL,
    reason TEXT NOT NULL,
    submitted_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (worker_id) REFERENCES workers (id)
);