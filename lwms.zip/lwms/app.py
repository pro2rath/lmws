# lwms/app.py
import os
import sqlite3
from flask import Flask, g
from config import DATABASE

# --- Database Setup ---
def get_db():
    """Connect to the application's configured database."""
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row  # Allows accessing columns by name
    return db

def init_db():
    """Initialize the database schema."""
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

def create_app():
    """Create and configure the Flask application."""
    app = Flask(__name__)
    app.config.from_pyfile('config.py')

    # Ensure instance folder exists
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # Register a command to initialize the DB
    @app.cli.command('init-db')
    def init_db_command():
        """Clear existing data and create new tables."""
        init_db()
        print('Initialized the database.')

    # Teardown app context to close the database connection
    @app.teardown_appcontext
    def close_connection(exception):
        db = getattr(g, '_database', None)
        if db is not None:
            db.close()

    # --- Register Blueprints ---
    from routes.register import register_bp
    from routes.verify import verify_bp
    from routes.daily import daily_bp
    from routes.search import search_bp
    from routes.complaint import complaint_bp
    from routes.admin import admin_bp

    app.register_blueprint(register_bp)
    app.register_blueprint(verify_bp)
    app.register_blueprint(daily_bp)
    app.register_blueprint(search_bp)
    app.register_blueprint(complaint_bp)
    app.register_blueprint(admin_bp)

    # --- Main Route ---
    @app.route('/')
    def index():
        from flask import render_template
        return render_template('index.html')

    @app.route('/privacy')
    def privacy_policy():
        from flask import render_template
        return render_template('privacy_policy.html')

    return app

# --- Database Schema Definition ---
# Create this file next
# File: lwms/schema.sql

if __name__ == '__main__':
    app = create_app()
    # Check if the database exists. If not, create it.
    if not os.path.exists(DATABASE):
        print("Database not found. Initializing...")
        init_db()
    app.run(debug=True)