# lwms/config.py
import os

# Application root directory
BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# Secret key for session management. Change this to a random string.
SECRET_KEY = 'your-super-secret-key-change-me'

# Database configuration
DATABASE = os.path.join(BASE_DIR, 'lwms.db')

# Uploads configuration
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}

# Admin credentials (for demonstration purposes)
# In a real application, use a more secure method like hashed passwords in a database.
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'password123'