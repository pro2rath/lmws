# lwms/routes/admin.py
import os
from functools import wraps
from flask import (
    Blueprint, render_template, request, flash, redirect, url_for, session, current_app
)
from app import get_db

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# --- Admin Authentication Decorator ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin_logged_in' not in session:
            return redirect(url_for('admin.login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == current_app.config['ADMIN_USERNAME'] and password == current_app.config['ADMIN_PASSWORD']:
            session['admin_logged_in'] = True
            flash('You were successfully logged in', 'success')
            return redirect(url_for('admin.panel'))
        else:
            flash('Invalid credentials', 'danger')
    return render_template('admin/login.html')

@admin_bp.route('/logout')
def logout():
    session.pop('admin_logged_in', None)
    flash('You were logged out', 'success')
    return redirect(url_for('admin.login'))

@admin_bp.route('/panel')
@login_required
def panel():
    db = get_db()
    unverified = db.execute('SELECT * FROM workers WHERE verified_status = 0').fetchall()
    verified = db.execute('SELECT * FROM workers WHERE verified_status = 1').fetchall()
    complaints = db.execute(
        'SELECT c.id, c.reason, c.submitted_on, w.name, w.id as worker_id FROM complaints c JOIN workers w ON c.worker_id = w.id ORDER BY c.submitted_on DESC'
    ).fetchall()
    return render_template('admin/admin_panel.html', unverified=unverified, verified=verified, complaints=complaints)

@admin_bp.route('/verify/<int:worker_id>')
@login_required
def verify_worker(worker_id):
    db = get_db()
    worker = db.execute('SELECT * FROM workers WHERE id = ?', (worker_id,)).fetchone()
    return render_template('admin/verify.html', worker=worker)

@admin_bp.route('/approve/<int:worker_id>', methods=['POST'])
@login_required
def approve_worker(worker_id):
    db = get_db()
    db.execute('UPDATE workers SET verified_status = 1 WHERE id = ?', (worker_id,))
    db.commit()
    flash(f'Worker ID {worker_id} has been approved.', 'success')
    return redirect(url_for('admin.panel'))

@admin_bp.route('/reject/<int:worker_id>', methods=['POST'])
@login_required
def reject_worker(worker_id):
    # For rejection, we delete the worker record and their files
    db = get_db()
    worker = db.execute('SELECT aadhaar_path, rationcard_path, selfie_path FROM workers WHERE id = ?', (worker_id,)).fetchone()
    
    # Delete files from server
    upload_folder = current_app.config['UPLOAD_FOLDER']
    for file_path in worker:
        if file_path:
            try:
                os.remove(os.path.join(upload_folder, file_path))
            except OSError as e:
                print(f"Error deleting file {file_path}: {e}")

    db.execute('DELETE FROM workers WHERE id = ?', (worker_id,))
    db.execute('DELETE FROM complaints WHERE worker_id = ?', (worker_id,)) # Also delete associated complaints
    db.commit()
    flash(f'Worker ID {worker_id} has been rejected and deleted.', 'warning')
    return redirect(url_for('admin.panel'))

@admin_bp.route('/toggle_block/<int:worker_id>', methods=['POST'])
@login_required
def toggle_block(worker_id):
    db = get_db()
    worker = db.execute('SELECT is_blocked FROM workers WHERE id = ?', (worker_id,)).fetchone()
    if worker:
        new_status = 1 - worker['is_blocked'] # Toggle status
        db.execute('UPDATE workers SET is_blocked = ? WHERE id = ?', (new_status, worker_id))
        db.commit()
        action = "blocked" if new_status == 1 else "unblocked"
        flash(f'Worker ID {worker_id} has been {action}.', 'success')
    return redirect(url_for('admin.panel'))

@admin_bp.route('/delete_complaint/<int:complaint_id>', methods=['POST'])
@login_required
def delete_complaint(complaint_id):
    db = get_db()
    db.execute('DELETE FROM complaints WHERE id = ?', (complaint_id,))
    db.commit()
    flash('Complaint has been deleted.', 'success')
    return redirect(url_for('admin.panel'))