# lwms/routes/daily.py
from flask import Blueprint, render_template, redirect, url_for, flash
from datetime import date
from app import get_db

daily_bp = Blueprint('daily', __name__)

@daily_bp.route('/daily')
def daily_view():
    """Shows workers who have marked themselves as available today."""
    today = date.today().isoformat()
    db = get_db()
    workers = db.execute(
        """
        SELECT id, name, phone, work_type, location, selfie_path 
        FROM workers 
        WHERE verified_status = 1 AND is_blocked = 0 AND last_available_date = ?
        ORDER BY name
        """,
        (today,)
    ).fetchall()
    return render_template('daily.html', workers=workers, today=today)

@daily_bp.route('/mark-available/<int:worker_id>')
def mark_available(worker_id):
    """A simple endpoint for a worker to mark themselves available."""
    today = date.today().isoformat()
    db = get_db()
    worker = db.execute('SELECT id FROM workers WHERE id = ?', (worker_id,)).fetchone()
    if worker:
        db.execute('UPDATE workers SET last_available_date = ? WHERE id = ?', (today, worker_id))
        db.commit()
        flash('நீங்கள் இன்று வேலைக்கு இருப்பதாகக் குறிக்கப்பட்டுள்ளது!', 'success')
    else:
        flash('Worker not found.', 'danger')
    
    # Redirect back to the search page or a specific worker profile page
    return redirect(url_for('search.search'))