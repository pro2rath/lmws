# lwms/routes/register.py
import os
from flask import Blueprint, render_template, request, flash, redirect, url_for, current_app
from werkzeug.utils import secure_filename
from app import get_db
from utils.validation import is_valid_aadhaar, allowed_file

register_bp = Blueprint('register', __name__)

@register_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        work_type = request.form['work_type']
        location = request.form['location']
        aadhaar_number = request.form['aadhaar_number']

        selfie_file = request.files['selfie']
        aadhaar_file = request.files['aadhaar_file']
        rationcard_file = request.files.get('rationcard_file') # Optional

        # --- Validation ---
        if not all([name, phone, work_type, location, aadhaar_number, selfie_file]):
            flash('அனைத்து புலங்களையும் நிரப்பவும்!', 'danger')
            return render_template('register.html')

        if not is_valid_aadhaar(aadhaar_number):
            flash('தவறான ஆதார் எண். 12 இலக்க எண்ணை உள்ளிடவும்.', 'danger')
            return render_template('register.html')
        
        db = get_db()
        existing_worker = db.execute('SELECT id FROM workers WHERE phone = ?', (phone,)).fetchone()
        if existing_worker:
            flash('இந்த தொலைபேசி எண் ஏற்கனவே பதிவு செய்யப்பட்டுள்ளது.', 'danger')
            return render_template('register.html')

        # --- File Handling ---
        upload_folder = current_app.config['UPLOAD_FOLDER']
        allowed_extensions = current_app.config['ALLOWED_EXTENSIONS']
        
        selfie_path, aadhaar_path, rationcard_path = None, None, None

        if selfie_file and allowed_file(selfie_file.filename, allowed_extensions):
            selfie_filename = secure_filename(f"selfie_{phone}.jpg")
            selfie_path = os.path.join('selfies', selfie_filename)
            selfie_file.save(os.path.join(upload_folder, selfie_path))
        else:
            flash('செல்ஃபி படம் தேவை.', 'danger')
            return render_template('register.html')

        if aadhaar_file and allowed_file(aadhaar_file.filename, allowed_extensions):
            aadhaar_filename = secure_filename(f"aadhaar_{phone}.jpg")
            aadhaar_path = os.path.join('aadhaar', aadhaar_filename)
            aadhaar_file.save(os.path.join(upload_folder, aadhaar_path))

        if rationcard_file and rationcard_file.filename and allowed_file(rationcard_file.filename, allowed_extensions):
            rationcard_filename = secure_filename(f"ration_{phone}.jpg")
            rationcard_path = os.path.join('rationcard', rationcard_filename)
            rationcard_file.save(os.path.join(upload_folder, rationcard_path))

        # --- Database Insert ---
        db.execute(
            """
            INSERT INTO workers (name, phone, work_type, location, aadhaar_path, rationcard_path, selfie_path)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (name, phone, work_type, location, aadhaar_path, rationcard_path, selfie_path)
        )
        db.commit()

        flash('பதிவு வெற்றிகரமாக முடிந்தது! நிர்வாகி ஒப்புதலுக்குப் பிறகு உங்கள் சுயவிவரம் தெரியும்.', 'success')
        return redirect(url_for('index'))

    return render_template('register.html')